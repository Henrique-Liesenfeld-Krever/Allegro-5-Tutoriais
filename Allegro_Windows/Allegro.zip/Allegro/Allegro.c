
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


// Inclui o arquivo de cabe�alho da biblioteca Allegro 5
#include <allegro5/allegro.h>

int main(int argc, char **argv) {

    // Inicializamos a biblioteca
    al_init();

    // Vari�vel representando a janela principal
    ALLEGRO_DISPLAY *janela = NULL;

    // Criamos a nossa janela - dimens�es de 640x480 px
    janela = al_create_display(640, 480);

    // Vari�vel contendo a cor branca
    ALLEGRO_COLOR cor_branca = al_map_rgb(255, 255, 255);

    // Limpa a tela com a cor desejada
    al_clear_to_color(cor_branca);

    // Atualiza a tela
    al_flip_display();

    // Fun��o do allegro parecida com o sleep
    al_rest(10.0);

    // Finaliza a janela
    al_destroy_display(janela);

    return 0;
}
